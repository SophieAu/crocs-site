/* eslint-disable @typescript-eslint/no-var-requires */
//@ts-check

const { createEvent, validateData, updateEvent } = require('./event-handling');
// const { updateEvent } = require('./event-update');
require('isomorphic-fetch');

const response = (code, message) => ({ statusCode: code, body: JSON.stringify({ message }) });

const fetchEvent = async id => {
  const response = await fetch('https://nitotqxp.api.sanity.io/v1/graphql/prod/default', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      query: `{ Event(id: "${id}") { _id name startTime tickets { name }} }`,
    }),
  });

  return response.json();
};

exports.handler = async event => {
  if (event.httpMethod !== 'POST') return response(405, 'HTTP Method must be POST');
  let hasError = false;
  let hasSuccess = false;

  const responses = [];

  try {
    const { ids } = JSON.parse(event.body);
    const { created, updated } = ids;

    if (created.length !== 0) {
      console.log('New Events: ', JSON.stringify(created));

      const responseData = (await Promise.all(created.map(async id => await fetchEvent(id))))
        .map(({ data }) => ({ ...data.Event, _id: data.Event._id.split('-')[0] }))
        .filter(Boolean);

      const creationResponses = await Promise.all(
        responseData.map(async data => {
          const error = validateData(data);

          if (!!error) {
            hasError = true;
            return error;
          } else {
            hasSuccess = true;
            return await createEvent(data);
          }
        })
      );

      creationResponses.forEach(res => {
        console.log(res.message);
        responses.push(res.message);
      });
    }

    if (updated.length !== 0) {
      console.log('Updated Events: ', JSON.stringify(updated));

      const responseData = (await Promise.all(updated.map(async id => await fetchEvent(id))))
        .map(({ data }) => ({ ...data.Event, _id: data.Event._id.split('-')[0] }))
        .filter(Boolean);

      const creationResponses = await Promise.all(
        responseData.map(async data => {
          const error = validateData(data);

          if (!!error) {
            hasError = true;
            return error;
          } else {
            hasSuccess = true;
            return await updateEvent(data);
          }
        })
      );

      creationResponses.forEach(res => {
        console.log(res.message);
        responses.push(res.message);
      });
    }

    if (hasError && !hasSuccess) return response(422, JSON.stringify(responses));
    if (hasError && hasSuccess) return response(207, JSON.stringify(responses));
    if (!hasError && hasSuccess) return response(200, JSON.stringify(responses));

    return response(200, 'No Updates');
  } catch (err) {
    console.error('error ocurred in processing ', event);
    console.error(err);
    return { statusCode: 500, body: err.toString() };
  }
};
