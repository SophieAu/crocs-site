/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable @typescript-eslint/no-var-requires */
//@ts-check

const { GoogleSpreadsheet } = require('google-spreadsheet');

function setup() {
  if (!process.env.NETLIFY) require('dotenv').config();

  function error(key) {
    console.error(`no ${key} env var set`);

    const error = new Error(`invalid server-side configuration`);
    error.stack = '';
    throw error;
  }

  if (!process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL) error('GOOGLE_SERVICE_ACCOUNT_EMAIL');
  if (!process.env.GOOGLE_PRIVATE_KEY) error('GOOGLE_PRIVATE_KEY');
  if (!process.env.GOOGLE_SPREADSHEET_ID_FROM_URL) error('GOOGLE_SPREADSHEET_ID_FROM_URL');
}
setup();

const response = (code, message) => ({
  statusCode: code,
  body: JSON.stringify({ message }),
  headers: {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept',
    'Content-Type': 'application/json',
    'Access-Control-Allow-Methods': '*',
    'Access-Control-Max-Age': 2592000,
    'Access-Control-Allow-Credentials': true,
  },
});

const loadDoc = async () => {
  const doc = new GoogleSpreadsheet(process.env.GOOGLE_SPREADSHEET_ID_FROM_URL);
  await doc.useServiceAccountAuth({
    client_email: process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL,
    private_key: process.env.GOOGLE_PRIVATE_KEY.replace(/\\n/g, '\n'),
  });
  await doc.loadInfo();

  return doc;
};

/*
--- BODY DATA
  id: string;
  name: string,
  email: string,
  [category]: number
  paid: boolean
*/

const baseFields = ['id', 'name', 'email', 'paid', 'bot-field'];

exports.handler = async event => {
  if (event.httpMethod === 'OPTIONS') return response(200, '');
  if (event.httpMethod !== 'POST') {
    console.log('405 - HTTP Method was: ', event.httpMethod);
    return response(405, 'HTTP Method must be POST or OPTIONS');
  }

  try {
    const doc = await loadDoc();

    const data = JSON.parse(event.body);
    if (!!data['bot-field']) return response(403, 'You look like a bot');

    if (baseFields.filter(f => !Object.keys(data).includes(f)).length > 0)
      return response(422, 'Payload is broken: Base Fields Missing');

    // transform categories
    const categories = {};
    const dataCats = Object.keys(data).filter(k => !baseFields.includes(k));
    dataCats.forEach(c => {
      const amount = parseInt(data[c], 10);
      if (isNaN(amount)) return;
      categories[c] = amount;
    });
    if (dataCats.length === 0) return response(422, 'Payload is broken: Missing Categories');

    const sheetTitle = Object.keys(doc.sheetsByTitle).find(title => title.includes(data.id));
    const sheet = doc.sheetsByTitle[sheetTitle];
    if (!sheet) return response(412, `Sheet '${sheetTitle}' doesn't exist`);

    const { _rowNumber } = await sheet.addRow({
      Timestamp: new Date().toISOString(),
      Name: encodeURI(data.name)
        .replace('%20', ' ')
        .replace(/[`~!@#$%^&*()_|+=?;:'",.<>\{\}\[\]\\\/]/gi, ''),
      Email: encodeURI(data.email).replace(/[`~!#$%^&*()|=?;:'",<>\{\}\[\]\\\/]/gi, ''),
      ...categories,
      Paid: Boolean(data.paid),
    });

    return response(200, `Signup for ${sheetTitle} successful. ID ${_rowNumber - 1}`);
  } catch (err) {
    console.error('error ocurred in processing ', event);
    console.error(err);
    return { statusCode: 500, body: err.toString() };
  }
};
