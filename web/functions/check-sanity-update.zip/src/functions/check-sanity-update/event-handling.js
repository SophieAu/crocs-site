/* eslint-disable @typescript-eslint/camelcase */
/* eslint-disable @typescript-eslint/no-var-requires */
//@ts-check

const { GoogleSpreadsheet } = require('google-spreadsheet');

function setup() {
  if (!process.env.NETLIFY) require('dotenv').config();

  function error(key) {
    throw new Error(`no ${key} env var set`);
  }

  if (!process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL) error('GOOGLE_SERVICE_ACCOUNT_EMAIL');
  if (!process.env.GOOGLE_PRIVATE_KEY) error('GOOGLE_PRIVATE_KEY');
  if (!process.env.GOOGLE_SPREADSHEET_ID_FROM_URL) error('GOOGLE_SPREADSHEET_ID_FROM_URL');
}
setup();

const response = (code, message) => ({ code, message });

const loadDoc = async () => {
  const doc = new GoogleSpreadsheet(process.env.GOOGLE_SPREADSHEET_ID_FROM_URL);
  await doc.useServiceAccountAuth({
    client_email: process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL,
    private_key: process.env.GOOGLE_PRIVATE_KEY.replace(/\\n/g, '\n'),
  });
  await doc.loadInfo();

  return doc;
};

const sanitizeId = id => id.replace(/[^a-zA-Z0-9]/g, '');

const sanitizedData = (id, title, date, tickets) => {
  const eventId = sanitizeId(id);
  const eventDate = new Date(date).toISOString().split('T')[0];
  const eventTitle = title.replace(/[^a-zA-Z ]/g, '');
  const eventTickets = tickets.map(t => t.name.toString().replace(/[^a-zA-Z\s]/g, ''));

  return { eventId, eventDate, eventTitle, eventTickets };
};

const buildEventTitle = (id, title, date) => `${date} ${title} (${id})`;

exports.updateEvent = async ({ _id, name, startTime, tickets }) => {
  try {
    const doc = await loadDoc();
    const sheets = doc.sheetsByTitle;

    const eventId = sanitizeId(_id);
    const oldTitle = Object.keys(sheets).find(sheet => sheet.includes(`(${eventId})`));
    if (!oldTitle) return response(409, `Sheet for event with id ${eventId} does not exist yet.`);

    const sheet = sheets[oldTitle];
    await sheet.loadHeaderRow();
    const oldHeaderValues = sheet.headerValues;

    const { eventDate, eventTitle, eventTickets } = sanitizedData(_id, name, startTime, tickets);

    const newTitle = buildEventTitle(eventId, eventTitle, eventDate);
    const newCategories = eventTickets.filter(c => !oldHeaderValues.includes(c));

    await sheet.updateProperties({ title: newTitle });
    await sheet.setHeaderRow([...oldHeaderValues, ...newCategories]);

    return response(200, `Sheet for event updated: ${newTitle}`);
  } catch (err) {
    console.error('error ocurred while trying to create event');
    console.error(err);
    return response(500, err.toString());
  }
};

exports.createEvent = async ({ _id, name, startTime, tickets }) => {
  try {
    const doc = await loadDoc();

    const { eventId, eventDate, eventTitle, eventTickets } = sanitizedData(
      _id,
      name,
      startTime,
      tickets
    );

    const sheetTitle = buildEventTitle(eventId, eventTitle, eventDate);

    if (!!doc.sheetsByTitle[sheetTitle])
      return response(409, `Sheet for event '${sheetTitle}' already exists.`);

    const headerValues = ['Timestamp', 'Name', 'Email', ...eventTickets, 'Paid'];

    const sheet = await doc.addSheet({ headerValues, title: sheetTitle });

    return response(200, `Sheet for event created: ${sheet.title}`);
  } catch (err) {
    console.error('error ocurred while trying to create event');
    console.error(err);
    return response(500, err.toString());
  }
};

exports.validateData = ({ _id, name, startTime, tickets }) => {
  if (!_id || !name || !startTime || !tickets)
    return response(422, 'Payload is broken: Missing Fields');

  const notAnArray = !Array.isArray(tickets) || tickets instanceof String;
  const emptyArray = tickets.length === 0;
  const badContent = !tickets[0].name;
  if (notAnArray || emptyArray || badContent)
    return response(422, 'Payload is broken: Misformed Ticket Categories');

  if (isNaN(Date.parse(startTime))) return response(422, 'Payload is broken: Invalid Date');
};
